import { BlogPost } from '../types';

export const blogPosts: BlogPost[] = [
  {
    id: '1',
    title: 'How to Choose the Perfect Home Theater Projector',
    excerpt: 'A comprehensive guide to selecting the right projector for your space.',
    content: `Choosing the perfect home theater projector can be overwhelming...`,
    author: 'Tech Expert Team',
    date: '2024-03-15',
    readTime: '8 min read',
    image: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&q=80'
  },
  {
    id: '2',
    title: 'Top 5 Home Theater Setup Tips for 2024',
    excerpt: 'Expert advice for creating the ultimate home cinema experience.',
    content: `Creating the perfect home theater setup requires careful planning...`,
    author: 'Cinema Pro Team',
    date: '2024-03-10',
    readTime: '6 min read',
    image: 'https://images.unsplash.com/photo-1593784991095-a205069470b6?auto=format&fit=crop&q=80'
  }
];