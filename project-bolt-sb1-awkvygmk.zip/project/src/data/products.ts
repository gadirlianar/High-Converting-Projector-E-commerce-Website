import { Product } from '../types';

export const products: Product[] = [
  {
    id: '1',
    name: 'CineMax Pro 4K',
    price: 999.99,
    description: 'Experience theater-quality projection with 4K resolution and HDR support.',
    features: [
      'True 4K Resolution (3840x2160)',
      'HDR10 Support',
      'Built-in 10W Speakers',
      'Smart TV Integration',
      'Wireless Screen Mirroring'
    ],
    specs: {
      lumens: 3000,
      resolution: '4K (3840x2160)',
      contrast: '100,000:1',
      lampLife: '20,000 hours'
    },
    stock: 3,
    images: [
      'https://images.unsplash.com/photo-1478720568477-152d9b164e26?auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1535016120720-40c646be5580?auto=format&fit=crop&q=80'
    ],
    rating: 4.8,
    reviews: 128
  },
  {
    id: '2',
    name: 'HomeVision 1080p',
    price: 599.99,
    description: 'Perfect for home entertainment with Full HD resolution and compact design.',
    features: [
      'Full HD Resolution',
      'Compact Design',
      'Easy Setup',
      'Multiple Input Ports',
      'Low Fan Noise'
    ],
    specs: {
      lumens: 2500,
      resolution: '1080p (1920x1080)',
      contrast: '50,000:1',
      lampLife: '15,000 hours'
    },
    stock: 7,
    images: [
      'https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?auto=format&fit=crop&q=80'
    ],
    rating: 4.6,
    reviews: 89
  }
];