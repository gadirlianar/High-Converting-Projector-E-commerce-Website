export interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  features: string[];
  specs: {
    lumens: number;
    resolution: string;
    contrast: string;
    lampLife: string;
  };
  stock: number;
  images: string[];
  rating: number;
  reviews: number;
}

export interface Review {
  id: string;
  author: string;
  rating: number;
  comment: string;
  date: string;
  verified: boolean;
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  date: string;
  readTime: string;
  image: string;
}